package ticketBooking.model;

import java.util.*;

public class Schedule {
	private String time;
	private Movie movie;
	private ArrayList<Seat> seat = new ArrayList<Seat>();

	public Schedule(String time, Movie movie) {
		this.time = time;
		this.movie = movie;
	}
	
	public void generateSeats() {
		for(char row = 'A'; row <= 'C'; row++) {
			for(int i = 1; i <= 10; i++) {
				seat.add(new Seat(row + String.valueOf(i)));
			}
		}
	}
	
	public String getTime() {
		return time;
	}
	
	public Movie getMovie() {
		return movie;
	}
	
	public List<Seat> getSeat() {
		return seat;
	}
	

}
