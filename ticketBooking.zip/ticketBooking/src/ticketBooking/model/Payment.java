package ticketBooking.model;

public interface Payment {
	void pay(double amount);
	String getMethod();
}
