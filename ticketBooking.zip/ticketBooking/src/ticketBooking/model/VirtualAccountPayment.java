package ticketBooking.model;

import java.util.*;

public class VirtualAccountPayment implements Payment {
	private String virtualAccount;

	public VirtualAccountPayment(String virtualAccount) {
		this.virtualAccount = generateVA();
	}
	
	public String getVirtualAccount() {
		return virtualAccount;
	}
	
	public String generateVA() {
		Random r = new Random();
		StringBuilder va = new StringBuilder();
		for(int i = 1; i <= 10; i++) {
			va.append(r.nextInt(10));
		}
		return va.toString();
	}
	
	@Override
	public void pay(double amount) {
		System.out.println("Virtual Account : " + virtualAccount
						 + "\nAmount          : Rp" + amount
						 + "\nStatus		: Success");
	}
	
	@Override
	public String getMethod() {
		return "Virtual Account";
	}

}
