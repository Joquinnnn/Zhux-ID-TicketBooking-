package ticketBooking.model;

public class Seat {
	private String seatNum;
	private boolean available;

	public Seat(String seatNum) {
		this.seatNum = seatNum;
		this.available = true;
	}
	
	public String getSeatNum() {
		return seatNum;
	}
	
	public boolean isAvailable() {
		return available;
	}
	
	public void booked() {
		this.available = false;
	}

}
