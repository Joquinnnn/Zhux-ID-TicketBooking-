package ticketBooking.model;

public class CardPayment implements Payment {
	private String cardNumber;

	public CardPayment(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	@Override
	public void pay(double amount) {
		System.out.println("Paid with card " + cardNumber + ": Rp " 
							+ amount);
	}
	
	@Override
	public String getMethod() {
		return "Card";
	}

}
