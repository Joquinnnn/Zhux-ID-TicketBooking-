package ticketBooking.model;

public class EWalletPayment implements Payment {
	private String provider;

	public EWalletPayment(String provider) {
		this.provider = provider;
	}
	
	@Override
	public void pay(double amount) {
		System.out.println("Paid via QRIS with " + provider + ": Rp " + amount);
	}

	@Override
	public String getMethod() {
		return "E-Wallet / QRIS";
	}
}
