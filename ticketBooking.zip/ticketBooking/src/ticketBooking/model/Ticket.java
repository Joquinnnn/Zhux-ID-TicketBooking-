package ticketBooking.model;

import java.util.*;

public class Ticket {
	private Schedule schedule;
	private Movie movie;
	private List<Seat> seat = new ArrayList<>();
	private double price;
	
	public Ticket(Schedule schedule, Movie movie, List<Seat> seat, double price) {
		this.schedule = schedule;
		this.movie = movie;
		this.seat = seat;
		this.price = price;
	}
	
	public Schedule getSchedule() {
		return schedule;
	}
	
	public Movie getMovie() {
		return movie;
	}
	
	public List<Seat> getSeat() {
		return seat;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}

}
