package ticketBooking.service;

import ticketBooking.model.*;
import java.util.*;

public class MovieService {
	private ArrayList<Schedule> schedules = new ArrayList<>();
	private Repository<Movie> movieRepo = new Repository<>();

	public void addMovie(Movie movie) {
		movieRepo.add(movie);
	}
	
	public ArrayList<Movie> getAllMovies(){
		return movieRepo.getAll();
	}
	
	public void addSchedule(Schedule schedule) {
		schedules.add(schedule);
	}
	
	public ArrayList<Schedule> getScheduleByMovie(Movie movie){
		ArrayList<Schedule> result = new ArrayList<>();
		for(Schedule s : schedules) {
			if(s.getMovie().equals(movie)) {
				result.add(s);
			}
		}
		return result;
	}

}
