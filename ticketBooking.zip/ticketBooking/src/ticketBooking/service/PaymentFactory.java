package ticketBooking.service;

import ticketBooking.model.*;

public class PaymentFactory {

	public static Payment createPayment(int choice, String detail) {
		return switch (choice) {
			case 1 -> new VirtualAccountPayment(detail);
			case 2 -> new CardPayment(detail);
			case 3 -> new EWalletPayment(detail);
			default -> throw new IllegalArgumentException("Invalid payment method");
		};
	}

}
	