package ticketBooking.service;

import java.util.*;

public class Repository<T> {
	private ArrayList<T> data = new ArrayList<>();
	
	public void add(T item) {
		data.add(item);
	}
	
	public ArrayList<T> getAll(){
		return data;
	}

	public boolean remove(T item) {
		return data.remove(item);
	}
}
