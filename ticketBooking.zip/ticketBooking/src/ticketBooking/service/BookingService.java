package ticketBooking.service;

import ticketBooking.model.*;
import java.util.*;

public class BookingService {

	private Repository<Booking> bookingRepo = new Repository<>();
	
	public void addBooking(Booking booking) {
		bookingRepo.add(booking);
	}
	
	public ArrayList<Booking> getAllBookings(){
		return bookingRepo.getAll();
	}
	
	public Booking findByBookingId(String Id) {
		for(Booking b : bookingRepo.getAll()) {
			if(b.getBookingId().equals(Id)) {
				return b;
			}
		}
		return null;
	}
	
	public Booking findByUserName(String name) {
		for(Booking b : bookingRepo.getAll()) {
			if(b.getUser().getName().equalsIgnoreCase(name)) {
				return b;
			}
		}
		return null;
	}
	
	public Booking findByMovieTitle(String title) {
		for(Booking b : bookingRepo.getAll()) {
			if(b.getTicket().getMovie().getTitle().equalsIgnoreCase(title)) {
				return b;
			}
		}
		return null;
	}
	
	public boolean cancelBooking(String Id) {
		return bookingRepo.getAll().removeIf(b -> b.getBookingId().equals(Id));
	}
	
	public void sortByPrice() {
		bookingRepo.getAll().sort(Comparator.comparingDouble(b -> b.getTicket().getPrice()));
	}

}
