package ticketBooking.service;

import ticketBooking.model.Payment;

public class PaymentService {
	
	public boolean process(Payment payment, double amount) {
		try {
			payment.pay(amount);
			return true;
		} catch (Exception e) {
			System.out.println("Payment failed: " + e.getMessage());
			return false;
		}

	}

}
