package ticketBooking.util;

import java.util.Scanner;

public class Console {
	Scanner sc = new Scanner(System.in);
	
	public String input(String message) {
		System.out.println(message);
		return sc.nextLine();
	}
	
	public void show(String message) {
		System.out.println(message);
	}
}
