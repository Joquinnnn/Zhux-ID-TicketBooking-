package ticketBooking.util;

import ticketBooking.model.*;
import java.util.*;

public class ReceiptUtil {
	
	public static void printReceipt(Booking booking) {
		Random r = new Random();
		System.out.println("===== RECEIPT =====");
		System.out.println("\nBooking ID : " + booking.getBookingId());
		System.out.println("\nTheater    : " + r.nextInt(1, 5));
		System.out.println("\nTime       : " + booking.getTicket().getSchedule().getTime());
		System.out.println("\nName       : " + booking.getUser().getName());
		System.out.println("\nMovie      : " + booking.getTicket().getMovie().getTitle());
		System.out.println("\nSeats      : ");
		for(Seat seat : booking.getTicket().getSeat()) {
			System.out.print(seat.getSeatNum() + " ");
		}
		System.out.println("\nPayment    : " + booking.getPayment().getMethod());
		System.out.println("\nPrice      : " + booking.getTicket().getPrice());
		System.out.println("\n===================");
	}

}
