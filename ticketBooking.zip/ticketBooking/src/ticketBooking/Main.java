package ticketBooking;

import ticketBooking.model.*;
import ticketBooking.service.*;
import ticketBooking.util.*;

import java.util.*;


public class Main {

    public static void main(String[] args) {
    	
    	Console console = new Console();
        MovieService movieService = new MovieService();
        BookingService bookingService = new BookingService();
        PaymentService paymentService = new PaymentService();

        /* 
           SEED MASTER DATA
        */
        Movie mov1 = new Movie("AVENGERS");
        Movie mov2 = new Movie("ZOOTOPIA 2");
        Movie mov3 = new Movie("AGAK LAEN");
        

        movieService.addMovie(mov1);
        movieService.addMovie(mov2);
        movieService.addMovie(mov3);
        
        String[] times = {"11:45", "13:15", "14:00", "16:15", "17:45", "20:05", "22:15"};
        
        for(Movie m : movieService.getAllMovies()) {
        	for(String time : times) {
        		Schedule s = new Schedule(time, m);
        		s.generateSeats();
        		movieService.addSchedule(s);
        	}
        }
    	
    	while(true) {

            /* 
               USER INPUT
            */
            console.show("=== ONLINE MOVIE TICKET BOOKING ===");
            String name = console.input("Enter your name:");
            User user = new User(name);

            
            /*
               CHOOSE MOVIE
            */
            console.show("\nAvailable Movies:");
            ArrayList<Movie> movies = movieService.getAllMovies();
            for (int i = 0; i < movies.size(); i++) {
                console.show((i + 1) + ". " + movies.get(i).getTitle());
            }

            int movieChoice = Integer.parseInt(console.input("Choose movie:")) - 1;
            Movie selectedMovie = movies.get(movieChoice);
            

            /* 
               CHOOSE SCHEDULE
             */
            List<Schedule> schedules = movieService.getScheduleByMovie(selectedMovie);

            console.show("\nAvailable Schedules:");
            for (int i = 0; i < schedules.size(); i++) {
                console.show((i + 1) + ". " + schedules.get(i).getTime());
            }

            int scheduleChoice = Integer.parseInt(console.input("Choose schedule:")) - 1;
            Schedule selectedSchedule = schedules.get(scheduleChoice);

            
            /* 
               CHOOSE SEAT
             */
            console.show("\nAvailable Seats:");
            for (Seat seat : selectedSchedule.getSeat()) {
                if (seat.isAvailable()) {
                    console.show(seat.getSeatNum());
                }
            }
            
            List<Seat> selectedSeats = new ArrayList<>();
            
            console.show("\nType seat number to select.");
            console.show("Type 'done' if finished.\n");
            
            while(true) {
            	String input = console.input("Choose Seat: "); 
            	
            	if(input.equalsIgnoreCase("done")) {
            		if(selectedSeats.isEmpty()) {
            			console.show("Must select at least 1 seat!");
            			continue;
            		}
            		break;
            	}
            	
            	Seat seats = selectedSchedule.getSeat()
            			.stream()
            			.filter(s -> s.getSeatNum().equalsIgnoreCase(input))
            			.findFirst()
            			.orElse(null);
            	
            	if(seats == null) {
            		console.show("Seat not found.");
            		continue;
            	}
            	
            	if(!seats.isAvailable()) {
            		console.show("Seat already booked.");
            		continue;
            	}
            	
            	if(selectedSeats.contains(seats)) {
            		console.show("Seat already selected.");
            		continue;
            	}
            	
            	seats.booked();
            	selectedSeats.add(seats);
            	console.show("Seat " + seats.getSeatNum() + " added.");
            	
            	for (Seat seat : selectedSchedule.getSeat()) {
                    if (seat.isAvailable()) {
                        console.show(seat.getSeatNum());
                    }
                }
            }
            

            /* 
               CREATE TICKET
            */
            double price = 45000;
            double totalPrice = price * selectedSeats.size();

            Ticket ticket = new Ticket(selectedSchedule,
                    				   selectedMovie,
                    				   selectedSeats,
                    				   totalPrice);

            
            /* 
               PAYMENT
             */
            console.show("\nPayment Method:");
            console.show("1. Virtual Account");
            console.show("2. Card (Debit/Credit)");
            console.show("3. E-Wallet / QRIS");
            
            
            int paymentChoice = Integer.parseInt(console.input("Choose payment:"));

            String detail = "";
            if (paymentChoice == 2) {
                detail = console.input("Enter card number:");
            } else if (paymentChoice == 3) {
                detail = console.input("Enter e-wallet provider:");
            }

            Payment payment = PaymentFactory.createPayment(paymentChoice, detail);

            boolean success = paymentService.process(payment, ticket.getPrice());

            if (!success) {
                console.show("Payment failed. Booking cancelled.");
                return;
            }

            
            /* 
               CREATE BOOKING
             */
            String bookingCode =
                    "BK-" + UUID.randomUUID().toString().substring(0, 8);
            
            console.show("Booking ID: " + bookingCode);

            Booking booking =
                    new Booking(bookingCode, user, ticket, payment);

            bookingService.addBooking(booking);
            
            
            /*
             MENU
             */
            
            while(true) {
            	console.show("\n===== BOOKING MENU =====");
            	console.show("1. Search Booking");
            	console.show("2. Sort Booking by Price");
            	console.show("3. Show All Bookings");
            	console.show("4. Exit");
            	
            	int menu = Integer.parseInt(console.input("Choose menu: "));
            	
            	if(menu == 1) {
            		console.show("\nSearch By:");
            		console.show("1. Booking ID");
            		console.show("2. User Name");
            		console.show("3. Movie Title");	
            		
            		int searchChoice = 	Integer.parseInt(console.input(">> "));
            		
            		Booking result = null;
            		
            		if(searchChoice == 1) {
            			String id = console.input("Enter Booking ID:");
            			result = bookingService.findByBookingId(id);
            		} else if(searchChoice == 2) {
            			String uname = console.input("Enter User Name:");
            			result = bookingService.findByUserName(uname);
            		} else if(searchChoice == 3) {
            			String title = console.input("Enter Movie Title:");
            			result = bookingService.findByMovieTitle(title);
            		}
            		
            		if(result != null) {
            			ReceiptUtil.printReceipt(result);
            		} else {
            			console.show("Booking not found.");
            		}
            	} else if(menu == 2){
            		bookingService.sortByPrice();
            	} else if(menu == 3) {
            		for(Booking b : bookingService.getAllBookings()) {
            			ReceiptUtil.printReceipt(b);
            		}
            	} else if(menu == 4) {
            		String again = console.input("Do you want to make another booking? (y/n)");
                    if(again.equalsIgnoreCase("y")) {
                    	break;
                    } else {
                    	console.show("\nThank you for booking!");
                        return;
                    }

            	} else {
            		console.show("Invalid menu!");
            	}
            }
    		
    	}
    }
}
